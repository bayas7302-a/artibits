=== Elementor Sheet Translator ===
Requires at least: 5.8
Requires PHP: 7.4
Stable tag: 1.8.1
License: GPLv2 or later

Translate an Elementor website with spreadsheets. English in column A, one column per language, import back, done.

== What it does ==

* Scans the whole site: Elementor pages, posts, headers, footers, popups, sections and
  other templates (including theme header/footer post types built with Elementor),
  block-editor / classic posts (e.g. case studies), navigation menus, site title and tagline.
* Export: one Excel workbook with one sheet per page, a ZIP with one CSV per page, a
  single CSV, or a single page from the Content screen.
* Every sheet: row 1 = "English (en) | Arabic (ar) | ...", column A = English text,
  the other columns = one language each (empty, or pre-filled with existing translations).
* Import: upload the filled .xlsx, .zip or .csv file(s). Each row is matched by its
  English text; empty cells are skipped and never delete a translation.
* Translated pages live at /ar/..., /fr/... (the default language stays at the root).
* Correct direction: <html dir="rtl" lang="ar">, WordPress/Elementor RTL stylesheets,
  body classes "rtl est-lang-ar est-dir-rtl" and optional per-language custom CSS.
* Internal links, menus and buttons keep the visitor in their language; hreflang tags for SEO.
* "Language Switcher" Elementor widget (dropdown or inline list) for your header, plus
  the shortcode [est_language_switcher].

== Quick start ==

1. Plugins > Add New > Upload Plugin, upload elementor-sheet-translator.zip and activate.
2. Sheet Translator > Languages & Settings > Add a language > Arabic.
3. Sheet Translator > Content & Export > Download export (Excel workbook).
4. Fill column B (Arabic) in every sheet. Keep any HTML tags such as <p> or <b>
   and translate only the text. Leave a cell empty to keep the English text.
5. Sheet Translator > Import, upload the file.
6. Edit your Elementor Header template, search the widget panel for "Language Switcher",
   drop it in, style it, update.
7. Visit https://your-site.com/ar/

To add another language later, add it in Languages & Settings and export again: the new
column appears in every sheet. You can also type a new header such as "French (fr)" in
the sheet; the import creates the language for you.

== Notes ==

* The same English text gets the same translation everywhere (e.g. "Contact us").
* After importing, the plugin purges WP Rocket, W3 Total Cache, WP Super Cache and
  LiteSpeed caches automatically. With other cache plugins, purge manually.
* Elementor's "Element Caching" is bypassed on translated pages so languages never mix.
* Some layouts use fixed "left/right" alignments or margins. Fix them for RTL pages with
  the language's Custom CSS box, e.g. `.est-dir-rtl .my-box { text-align: right; }`.
* If a widget text is missing from the export, add its setting key under
  "Extra Elementor setting keys to translate".
* Images: Sheet Translator > Images lets you pick a different image per language
  (image widgets, backgrounds, galleries, post images). Tick "Include image URLs" on
  export to get an "Images" sheet; on import, rows whose column A is an image URL are
  mapped automatically.
* Contact Form 7: every form is its own sheet ("Contact Form - ...") with its labels,
  placeholders, dropdown/checkbox options, submit button and messages. Forms inside
  popups are translated too, and the "sent" / error messages come back translated.
* "Language Buttons" Elementor widget (in addition to "Language Switcher"): shows every
  language as a button (EN | AR | FR) or as a dropdown, labelled by code or name, with
  background / text / border colours for normal, hover and active states, padding,
  spacing, border width and radius.
* Both switcher widgets have a "Button style" section with Normal / Hover / Active tabs:
  text colour, background (solid or gradient), border (type, width, colour; "None"
  removes it), border radius and box shadow, plus padding. Active = the current language
  or the dropdown button while open.
* Language Buttons "Text with dividers" layout (FR | EN | ES): divider lines (colour,
  height, thickness) and an underline under the active language, optionally also on
  hover (colours, thickness, width, distance). Normal / hover / active text colours are
  in the Button style tabs.
* "Default language for visitors" (Languages & Settings > Settings): choose which
  language is shown at the main address (site.com/). The source language then gets its
  own prefix (e.g. /en/). Pages are still edited in the source language and the
  spreadsheets are unchanged.
* Language order (Languages & Settings): drag the languages to set their order in the
  switchers. The default language for visitors comes first, and moves to the front
  whenever the default is changed.
* Separate design per language (optional, OFF by default - Languages & Settings > "Allow a
  separate Elementor design per language"). While off, the Elementor editor has no
  language options and the site is translated from the spreadsheets only.
  When on: "Create AR version" (Pages / Posts / Templates lists,
  the Content screen, the admin bar on a translated page, or the language bar at the
  bottom of the Elementor editor) makes a copy with the sheet translations applied.
  Edit it freely in Elementor - text, styling, layout. Visitors on /ar/ see the copy
  wherever the original appears (pages, posts, headers, footers, popups); URLs, menus
  and theme assignments stay on the original. Copies have no URL of their own (they
  redirect), are left out of sitemaps and listings, and are listed under
  "Language versions" in the admin. Text still in English inside a copy keeps
  being translated from the sheets. Trashing/deleting the original does the same to
  its copies.
* SEO (Sheet Translator > SEO): meta title and description per page for every language
  (source language included), with character counters. Replaces the <title> and meta
  description on that language's pages - on its own, or through Yoast SEO / Rank Math.
  Export with "Include SEO meta" to get a separate "SEO" sheet (SEO page | Field |
  English | Arabic | ...); importing it maps the values back to each page by its ID or by its address (e.g. /about/ or /en/about/).
